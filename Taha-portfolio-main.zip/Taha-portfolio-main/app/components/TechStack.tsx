"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import {
  FaDatabase, FaFileExcel, FaChartBar, FaChartLine,
  FaChartArea, FaServer, FaWarehouse, FaTruck,
  FaBoxes, FaClipboardList, FaShieldAlt, FaSyncAlt,
  FaIndustry, FaCogs, FaTruckMoving, FaBoxOpen,
} from "react-icons/fa";
import { SiSap, SiMysql } from "react-icons/si";

const row1 = [
  { Icon: FaDatabase,      label: "Oracle ERP",         color: "#f97316" },
  { Icon: SiSap,           label: "SAP",                color: "#2CFF05" },
  { Icon: FaChartBar,      label: "Power BI",           color: "#f59e0b" },
  { Icon: FaFileExcel,     label: "Microsoft Excel",    color: "#16a34a" },
  { Icon: FaChartLine,     label: "KPI Dashboards",     color: "#2CFF05" },
  { Icon: FaServer,        label: "ERP Systems",        color: "#60a5fa" },
  { Icon: FaWarehouse,     label: "Warehouse Mgmt",     color: "#2CFF05" },
  { Icon: FaSyncAlt,       label: "Cycle Counts",       color: "#a78bfa" },
];

const row2 = [
  { Icon: FaTruck,         label: "Inbound Logistics",  color: "#2CFF05" },
  { Icon: FaBoxes,         label: "Inventory Control",  color: "#fb923c" },
  { Icon: FaChartArea,     label: "ETL & Reporting",    color: "#38bdf8" },
  { Icon: FaShieldAlt,     label: "QEHS Compliance",    color: "#2CFF05" },
  { Icon: FaClipboardList, label: "Audit Management",   color: "#e879f9" },
  { Icon: FaIndustry,      label: "Supply Chain",       color: "#2CFF05" },
  { Icon: SiMysql,         label: "SQL & Data",         color: "#00758f" },
  { Icon: FaTruckMoving,   label: "Cross-Dock Ops",     color: "#2CFF05" },
];

type TechItem = { Icon: React.ElementType; label: string; color: string };

function MarqueeRow({ items, direction }: { items: TechItem[]; direction: "left" | "right" }) {
  const doubled = [...items, ...items, ...items, ...items];
  return (
    <div className="marquee-wrap overflow-hidden">
      <div className={`marquee-track marquee-${direction} gap-4 py-1`}>
        {doubled.map(({ Icon, label, color }, i) => (
          <div
            key={i}
            className="flex items-center gap-3 px-5 py-3 rounded-xl flex-shrink-0 group cursor-default transition-all duration-300"
            style={{
              background: "var(--bg-card)",
              border: "1px solid var(--border)",
              minWidth: "max-content",
            }}
            onMouseEnter={e => {
              (e.currentTarget as HTMLElement).style.borderColor = color;
              (e.currentTarget as HTMLElement).style.boxShadow = `0 0 16px ${color}30`;
            }}
            onMouseLeave={e => {
              (e.currentTarget as HTMLElement).style.borderColor = "var(--border)";
              (e.currentTarget as HTMLElement).style.boxShadow = "none";
            }}
          >
            <Icon size={20} style={{ color, flexShrink: 0 }} />
            <span className="text-xs font-semibold" style={{ color: "var(--text-muted)" }}>
              {label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function TechStack() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: false, margin: "-60px" });

  return (
    <section className="py-16 relative overflow-hidden" style={{ background: "#040404" }}>
      {/* Fade edges */}
      <div className="absolute inset-y-0 left-0 w-20 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to right, #040404, transparent)" }} />
      <div className="absolute inset-y-0 right-0 w-20 z-10 pointer-events-none"
        style={{ background: "linear-gradient(to left, #040404, transparent)" }} />

      <div className="max-w-6xl mx-auto px-6 mb-8" ref={ref}>
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
          transition={{ duration: 0.5 }}
        >
          <span className="section-label">Tech Stack</span>
        </motion.div>
        <motion.h3
          initial={{ opacity: 0, y: 16 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
          transition={{ duration: 0.55, delay: 0.08 }}
          className="text-2xl sm:text-3xl font-black"
        >
          Tools &{" "}
          <span style={{ color: "var(--accent)" }}>Technologies</span>
        </motion.h3>
      </div>

      <div className="flex flex-col gap-4">
        <MarqueeRow items={row1} direction="left" />
        <MarqueeRow items={row2} direction="right" />
      </div>
    </section>
  );
}
