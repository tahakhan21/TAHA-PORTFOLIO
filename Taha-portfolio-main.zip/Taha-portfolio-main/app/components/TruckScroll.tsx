"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

function TruckSVG() {
  return (
    <svg
      viewBox="0 0 120 60"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="w-32 h-16 drop-shadow-lg"
    >
      {/* Trailer */}
      <rect x="2" y="12" width="72" height="32" rx="4" fill="#1a1a2e" stroke="#7c3aed" strokeWidth="1.5" />
      <rect x="4" y="14" width="68" height="10" rx="2" fill="#0f0f1f" />
      {/* Trailer logo */}
      <text x="28" y="23" fill="#a78bfa" fontSize="6" fontWeight="bold" fontFamily="monospace">TAMER</text>
      <text x="22" y="31" fill="#34d399" fontSize="4" fontFamily="monospace">LOGISTICS</text>
      {/* Vertical slats */}
      {[14, 26, 38, 50, 62].map((x) => (
        <line key={x} x1={x} y1="26" x2={x} y2="42" stroke="#2a2a3e" strokeWidth="1" />
      ))}
      {/* Cab */}
      <rect x="74" y="18" width="38" height="26" rx="4" fill="#0d0d1a" stroke="#7c3aed" strokeWidth="1.5" />
      {/* Windshield */}
      <rect x="90" y="20" width="18" height="12" rx="2" fill="#1a1a2e" stroke="#a78bfa" strokeWidth="1" />
      <line x1="99" y1="20" x2="99" y2="32" stroke="#a78bfa" strokeWidth="0.5" opacity="0.6" />
      {/* Door */}
      <rect x="75" y="22" width="13" height="16" rx="2" fill="#111126" stroke="#2a2a3e" strokeWidth="0.8" />
      <circle cx="86" cy="30" r="1.2" fill="#7c3aed" />
      {/* Exhaust stack */}
      <rect x="82" y="10" width="3" height="10" rx="1" fill="#1a1a2e" stroke="#7c3aed" strokeWidth="0.8" />
      {/* Exhaust smoke */}
      <circle cx="83" cy="8" r="2" fill="#2a2a3e" opacity="0.6" />
      <circle cx="85" cy="5" r="1.5" fill="#1a1a2e" opacity="0.4" />
      <circle cx="83" cy="3" r="1" fill="#0f0f1f" opacity="0.3" />
      {/* Grill */}
      <rect x="110" y="22" width="6" height="14" rx="1" fill="#0f0f1a" stroke="#7c3aed" strokeWidth="0.8" />
      {[24, 28, 32].map((y) => (
        <line key={y} x1="110" y1={y} x2="116" y2={y} stroke="#a78bfa" strokeWidth="0.5" opacity="0.7" />
      ))}
      {/* Headlight */}
      <rect x="113" y="22" width="4" height="5" rx="1" fill="#fffde7" opacity="0.9" />
      {/* Connector */}
      <rect x="72" y="26" width="4" height="8" rx="1" fill="#7c3aed" opacity="0.7" />
      {/* Rear wheels */}
      <circle cx="16" cy="44" r="8" fill="#111" stroke="#7c3aed" strokeWidth="1.5" />
      <circle cx="16" cy="44" r="4" fill="#1a1a2e" />
      <circle cx="16" cy="44" r="1.5" fill="#7c3aed" />
      <circle cx="40" cy="44" r="8" fill="#111" stroke="#7c3aed" strokeWidth="1.5" />
      <circle cx="40" cy="44" r="4" fill="#1a1a2e" />
      <circle cx="40" cy="44" r="1.5" fill="#7c3aed" />
      {/* Front wheel */}
      <circle cx="100" cy="44" r="7" fill="#111" stroke="#a78bfa" strokeWidth="1.5" />
      <circle cx="100" cy="44" r="3.5" fill="#1a1a2e" />
      <circle cx="100" cy="44" r="1.5" fill="#a78bfa" />
      {/* Running lights */}
      <circle cx="76" cy="20" r="1.5" fill="#f59e0b" opacity="0.8" />
      <circle cx="76" cy="40" r="1.5" fill="#ef4444" opacity="0.8" />
      {/* Bumper */}
      <rect x="108" y="38" width="10" height="4" rx="1" fill="#1a1a2e" stroke="#7c3aed" strokeWidth="0.8" />
    </svg>
  );
}

export default function TruckScroll() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"],
  });

  const x = useTransform(scrollYProgress, [0, 1], ["-10%", "100%"]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 2]);

  return (
    <section
      ref={sectionRef}
      className="relative py-0 overflow-hidden"
      style={{ background: "#0a0a0a" }}
    >
      {/* Section heading above road */}
      <div className="text-center pt-12 pb-4 px-6">
        <span className="section-label justify-center">
          On The Road
        </span>
        <p className="text-sm mt-2" style={{ color: "var(--text-dim)" }}>
          Keeping supply chains moving — always on time, always on track
        </p>
      </div>

      {/* Road */}
      <div className="relative mt-4" style={{ height: "100px" }}>
        {/* Sky-ground divide */}
        <div
          className="absolute inset-x-0 bottom-0 h-20"
          style={{ background: "#0d0d0d", borderTop: "2px solid #1a1a1a" }}
        />

        {/* Road surface */}
        <div
          className="absolute inset-x-0 bottom-0"
          style={{ height: "56px", background: "#0f0f0f" }}
        />

        {/* Road markings – dashed center line */}
        <div
          className="absolute inset-x-0"
          style={{
            bottom: "26px",
            height: "4px",
            background: "repeating-linear-gradient(90deg, #7c3aed 0px, #7c3aed 32px, transparent 32px, transparent 64px)",
            opacity: 0.4,
          }}
        />

        {/* Edge lines */}
        <div
          className="absolute inset-x-0"
          style={{ bottom: "54px", height: "2px", background: "rgba(255,255,255,0.06)" }}
        />
        <div
          className="absolute inset-x-0"
          style={{ bottom: "2px", height: "2px", background: "rgba(255,255,255,0.04)" }}
        />

        {/* Lamp posts */}
        {[10, 30, 50, 70, 90].map((pct) => (
          <div
            key={pct}
            className="absolute flex flex-col items-center"
            style={{ left: `${pct}%`, bottom: "54px" }}
          >
            <div
              className="w-0.5 h-8"
              style={{ background: "#1f1f1f" }}
            />
            <div
              className="w-3 h-0.5 mb-1"
              style={{ background: "#1f1f1f", marginTop: "-2px" }}
            />
          </div>
        ))}

        {/* Moving truck */}
        <motion.div
          style={{ x, rotate, position: "absolute", bottom: "44px", left: 0 }}
        >
          <TruckSVG />
        </motion.div>

        {/* Speed lines behind truck */}
        <motion.div
          style={{ x, position: "absolute", bottom: "60px", left: "-60px", opacity: 0.3 }}
        >
          {[0, 8, 16].map((offset) => (
            <div
              key={offset}
              style={{
                height: "1px",
                width: "40px",
                background: "linear-gradient(90deg, transparent, var(--purple-light))",
                marginBottom: `${offset}px`,
              }}
            />
          ))}
        </motion.div>
      </div>

      {/* Stats row */}
      <div className="max-w-4xl mx-auto px-6 pb-10 pt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { value: "2+", label: "Year in Logistics" },
          { value: "100%", label: "Audit Compliance" },
          { value: "ERP", label: "Oracle Powered" },
          { value: "KPI", label: "Real-time Reporting" },
        ].map((s) => (
          <div
            key={s.label}
            className="card p-4 text-center"
          >
            <div
              className="text-xl font-extrabold"
              style={{ color: "var(--purple-light)" }}
            >
              {s.value}
            </div>
            <div className="text-xs mt-1" style={{ color: "var(--text-dim)" }}>
              {s.label}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
