"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";

interface AnimatedTextProps {
  text: string;
  className?: string;
  style?: React.CSSProperties;
  delay?: number;
  type?: "words" | "chars";
  stagger?: number;
}

export default function AnimatedText({
  text,
  className = "",
  style,
  delay = 0,
  type = "words",
  stagger = 0.06,
}: AnimatedTextProps) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: false, margin: "-40px" });

  const units = type === "chars" ? text.split("") : text.split(" ");

  return (
    <span ref={ref} className={`inline-flex flex-wrap gap-x-[0.3em] ${className}`} style={style} aria-label={text}>
      {units.map((unit, i) => (
        <motion.span
          key={i}
          initial={{ opacity: 0, y: 22, filter: "blur(4px)" }}
          animate={inView ? { opacity: 1, y: 0, filter: "blur(0px)" } : { opacity: 0, y: 22, filter: "blur(4px)" }}
          transition={{
            duration: 0.5,
            delay: delay + i * stagger,
            ease: [0.22, 1, 0.36, 1],
          }}
          className="inline-block"
        >
          {unit === " " ? " " : unit}
        </motion.span>
      ))}
    </span>
  );
}
