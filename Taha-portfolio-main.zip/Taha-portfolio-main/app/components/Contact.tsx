"use client";

import { motion } from "framer-motion";
import { FaEnvelope, FaPhone, FaMapMarkerAlt, FaPaperPlane } from "react-icons/fa";
import AnimatedText from "./AnimatedText";

const VP = { once: false, margin: "-60px" } as const;

const contacts = [
  { Icon: FaEnvelope,     label: "Email",    value: "Tahaasghar21@gmail.com", href: "https://mail.google.com/mail/?view=cm&fs=1&to=Tahaasghar21@gmail.com" },
  { Icon: FaPhone,        label: "Phone",    value: "+966 568721572",          href: "tel:+966568721572" },
  { Icon: FaMapMarkerAlt, label: "Location", value: "Jeddah, Saudi Arabia",   href: null },
];

export default function Contact() {
  return (
    <section id="contact" className="py-28 px-6 relative overflow-hidden">
      <div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[700px] h-[250px] pointer-events-none"
        style={{ background: "radial-gradient(ellipse, rgba(44,255,5,0.07) 0%, transparent 70%)", filter: "blur(30px)" }}
      />

      <div className="max-w-4xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={VP}
          transition={{ duration: 0.5 }}
          className="flex justify-center"
        >
          <span className="section-label">Get In Touch</span>
        </motion.div>

        <h2 className="text-4xl sm:text-5xl font-black mb-4 text-center leading-tight">
          <AnimatedText text="Let's" delay={0.05} />
          {" "}
          <span style={{ color: "var(--accent)" }}>
            <AnimatedText text="Connect" delay={0.2} />
          </span>
        </h2>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={VP}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="text-sm max-w-md mx-auto text-center mb-12 leading-relaxed"
          style={{ color: "var(--text-muted)" }}
        >
          Open to warehouse supervision roles, logistics management positions,
          and supply chain opportunities in Saudi Arabia and beyond.
        </motion.p>

        <div className="grid sm:grid-cols-3 gap-4 mb-10">
          {contacts.map(({ Icon, label, value, href }, i) => {
            const inner = (
              <motion.div
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ duration: 0.55, delay: 0.3 + i * 0.1 }}
                whileHover={{ y: -5, borderColor: "rgba(44,255,5,0.4)" }}
                className="card p-6 flex flex-col items-center text-center gap-3 h-full"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: "var(--accent-dim)", color: "var(--accent)", border: "1px solid rgba(44,255,5,0.2)" }}
                >
                  <Icon size={20} />
                </div>
                <div className="text-xs font-black uppercase tracking-widest" style={{ color: "var(--text-dim)" }}>
                  {label}
                </div>
                <div className="text-sm font-semibold break-all" style={{ color: "var(--text)" }}>
                  {value}
                </div>
              </motion.div>
            );
            return href ? (
              <a key={label} href={href} className="block" target="_blank" rel="noopener noreferrer">{inner}</a>
            ) : (
              <div key={label}>{inner}</div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={VP}
          transition={{ duration: 0.55, delay: 0.6 }}
          className="text-center"
        >
          <motion.a
            href="https://mail.google.com/mail/?view=cm&fs=1&to=Tahaasghar21@gmail.com"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05, boxShadow: "0 0 36px rgba(44,255,5,0.4)" }}
            whileTap={{ scale: 0.97 }}
            className="inline-flex items-center gap-3 px-8 py-4 rounded-xl text-sm font-black text-black tracking-wide"
            style={{ background: "var(--accent)" }}
          >
            <FaPaperPlane size={14} />
            Send an Email
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
