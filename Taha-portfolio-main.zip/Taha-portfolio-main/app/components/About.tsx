"use client";

import { motion } from "framer-motion";
import { FaMapMarkerAlt, FaEnvelope, FaPhone, FaLanguage, FaTrophy } from "react-icons/fa";
import AnimatedText from "./AnimatedText";

const VP = { once: false, margin: "-80px" } as const;

const info = [
  { icon: FaMapMarkerAlt, label: "Location", value: "Jeddah, Saudi Arabia" },
  { icon: FaEnvelope,     label: "Email",    value: "Tahaasghar21@gmail.com" },
  { icon: FaPhone,        label: "Phone",    value: "+966 568721572" },
  { icon: FaLanguage,     label: "Languages",value: "English · Arabic · Urdu" },
];

const summaryLines = [
  "Detail-oriented and results-driven Warehouse & Logistics Professional with over 1 year of hands-on experience in warehouse operations, inbound logistics, inventory control, and supply chain coordination.",
  "Proficient in using ERP systems (Oracle) and Power BI to drive data-informed decisions. Proven track record of optimizing warehouse workflows, improving inventory accuracy, and ensuring regulatory and safety compliance.",
  "Recognized for cross-functional collaboration, leadership potential, and process improvement — ready to take the next step as a Supervisor.",
];

export default function About() {
  return (
    <section id="about" className="py-28 px-6 relative overflow-hidden">
      <div className="absolute inset-0 dot-bg opacity-30 pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={VP}
          transition={{ duration: 0.5 }}
        >
          <span className="section-label">About Me</span>
        </motion.div>

        <h2 className="text-4xl sm:text-5xl font-black mb-12 leading-tight">
          <AnimatedText text="Who I" delay={0.05} />
          {" "}
          <span style={{ color: "var(--accent)" }}>
            <AnimatedText text="Am" delay={0.2} />
          </span>
        </h2>

        <div className="grid md:grid-cols-2 gap-14">
          {/* Summary */}
          <div className="flex flex-col gap-5">
            {summaryLines.map((line, i) => (
              <motion.p
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ duration: 0.6, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] }}
                className="text-sm leading-7"
                style={{ color: "var(--text-muted)" }}
              >
                {line}
              </motion.p>
            ))}

            {/* Trophy badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.88, y: 16 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={VP}
              transition={{ duration: 0.6, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ scale: 1.02 }}
              className="mt-2 p-5 rounded-xl flex items-center gap-4 animate-pulse-glow"
              style={{
                background: "rgba(44,255,5,0.05)",
                border: "1px solid rgba(44,255,5,0.25)",
              }}
            >
              <motion.div
                animate={{ rotate: [-4, 4, -4] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                style={{ color: "var(--accent)" }}
              >
                <FaTrophy size={32} />
              </motion.div>
              <div>
                <div className="text-sm font-black" style={{ color: "var(--accent)" }}>Employee of the Year</div>
                <div className="text-xs mt-0.5" style={{ color: "var(--text-dim)" }}>
                  Tamer Logistics — Top performer recognition
                </div>
              </div>
            </motion.div>
          </div>

          {/* Info cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 self-start">
            {info.map(({ icon: Icon, label, value }, i) => (
              <motion.div
                key={label}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ duration: 0.55, delay: i * 0.09, ease: [0.22, 1, 0.36, 1] }}
                whileHover={{ y: -3, borderColor: "rgba(44,255,5,0.4)" }}
                className="card p-4 flex items-start gap-3"
              >
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5"
                  style={{ background: "var(--accent-dim)", color: "var(--accent)" }}
                >
                  <Icon size={14} />
                </div>
                <div>
                  <div className="text-xs font-bold tracking-widest uppercase mb-0.5" style={{ color: "var(--text-dim)" }}>
                    {label}
                  </div>
                  <div className="text-sm font-medium" style={{ color: "var(--text)" }}>
                    {value}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
