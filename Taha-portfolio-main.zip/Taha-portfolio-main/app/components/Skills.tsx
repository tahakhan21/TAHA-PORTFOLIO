"use client";

import { motion } from "framer-motion";
import { FaWarehouse, FaLaptopCode, FaShieldAlt } from "react-icons/fa";
import AnimatedText from "./AnimatedText";

const VP = { once: false, margin: "-60px" } as const;

const categories = [
  {
    title: "Warehouse & Operations",
    Icon: FaWarehouse,
    skills: [
      "Warehouse & Logistics Supervision",
      "Inbound & Outbound Operations",
      "Inventory Control & Audits",
      "Cycle Counts & Co-Packing",
      "Cross-Dock Operations",
      "Equipment & Resource Allocation",
    ],
  },
  {
    title: "Technology & Data",
    Icon: FaLaptopCode,
    skills: [
      "Oracle E-Business Suite",
      "SAP Fundamentals",
      "Microsoft Excel",
      "Power BI (ETL & Reporting)",
      "KPI Dashboards",
      "MS Office Suite",
    ],
  },
  {
    title: "Compliance & Leadership",
    Icon: FaShieldAlt,
    skills: [
      "Safety & QEHS Compliance",
      "KPI Monitoring & Reporting",
      "Team Collaboration",
      "Performance Support",
      "Process Improvement",
      "Cross-functional Coordination",
    ],
  },
];

export default function Skills() {
  return (
    <section id="skills" className="py-28 px-6 relative" style={{ background: "#000" }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={VP}
          transition={{ duration: 0.5 }}
        >
          <span className="section-label">Core Skills</span>
        </motion.div>

        <h2 className="text-4xl sm:text-5xl font-black mb-14 leading-tight">
          <AnimatedText text="What I" delay={0.05} />
          {" "}
          <span style={{ color: "var(--accent)" }}>
            <AnimatedText text="Do" delay={0.2} />
          </span>
        </h2>

        <div className="grid md:grid-cols-3 gap-5">
          {categories.map(({ title, Icon, skills }, ci) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 48 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={VP}
              transition={{ duration: 0.65, delay: ci * 0.12, ease: [0.22, 1, 0.36, 1] }}
              whileHover={{ y: -5 }}
              className="card p-6 relative overflow-hidden group"
            >
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none rounded-xl"
                style={{ background: "radial-gradient(circle at 50% 0%, rgba(44,255,5,0.06) 0%, transparent 70%)" }}
              />

              <div className="flex items-center gap-3 mb-6">
                <motion.div
                  whileHover={{ rotate: 10, scale: 1.1 }}
                  className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{ background: "var(--accent-dim)", color: "var(--accent)", border: "1px solid rgba(44,255,5,0.2)" }}
                >
                  <Icon size={18} />
                </motion.div>
                <h3 className="text-sm font-black" style={{ color: "var(--text)" }}>{title}</h3>
              </div>

              <motion.div
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={VP}
                transition={{ duration: 0.6, delay: ci * 0.12 + 0.25 }}
                className="mb-5 h-px origin-left"
                style={{ background: "var(--border)" }}
              />

              <ul className="flex flex-col gap-2.5">
                {skills.map((skill, si) => (
                  <motion.li
                    key={skill}
                    initial={{ opacity: 0, x: -14 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={VP}
                    transition={{ duration: 0.4, delay: ci * 0.12 + si * 0.05 + 0.3 }}
                    className="flex items-center gap-2.5 text-xs"
                    style={{ color: "var(--text-muted)" }}
                  >
                    <span className="w-1 h-1 rounded-full flex-shrink-0" style={{ background: "var(--accent)" }} />
                    {skill}
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
