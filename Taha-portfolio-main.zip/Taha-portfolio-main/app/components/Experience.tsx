"use client";

import { motion } from "framer-motion";
import { FaBriefcase, FaCalendarAlt, FaMapMarkerAlt } from "react-icons/fa";
import { HiOfficeBuilding } from "react-icons/hi";
import AnimatedText from "./AnimatedText";

const VP      = { once: false, margin: "-60px" } as const;
const VP_LINE = { once: false, margin: "-40px" } as const;

const jobs = [
  {
    title: "Warehouse Operation Coordinator",
    company: "Tamer Logistics",
    location: "Jeddah, Saudi Arabia",
    period: "Jan 2024 – Present",
    current: true,
    bullets: [
      "Handle inbound logistics and ensure timely receipt and documentation of local/international shipments.",
      "Check quality standards of goods in new shipments to ensure compliance with company requirements.",
      "Conduct inventory audits, cycle counts, and implement wall-to-wall audits to reduce variances.",
      "Coordinate manpower and equipment needs based on daily workload forecasts.",
      "Use Oracle ERP to manage stock records and ensure real-time system accuracy.",
      "Collaborate with IT, supply chain, and co-packing teams to resolve system delays and manage value-added services.",
      "Ensure compliance with safety protocols during inspections and warehouse activities.",
      "Track and report on key metrics including turnaround time, inventory levels, and warehouse utilization.",
      "Support cross-dock operations and contribute to continuous improvement initiatives in warehouse flow.",
    ],
  },
  {
    title: "Research Intern – AI & Deep Learning",
    company: "The Game Company",
    location: "Dubai, UAE (Remote)",
    period: "Sep 2023 – Dec 2023",
    current: false,
    bullets: [
      "Evaluated and benchmarked AI models for real-time applications.",
      "Worked with cross-functional teams to ensure effective deployment of AI within gaming environments.",
      "Researched how AI techniques can enhance user gameplay experience, improve game smoothness, and optimize server performance through intelligent automation.",
    ],
  },
];

export default function Experience() {
  return (
    <section id="experience" className="py-28 px-6 relative overflow-hidden">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={VP}
          transition={{ duration: 0.5 }}
        >
          <span className="section-label">Experience</span>
        </motion.div>

        <h2 className="text-4xl sm:text-5xl font-black mb-14 leading-tight">
          <AnimatedText text="My" delay={0.05} />
          {" "}
          <span style={{ color: "var(--accent)" }}>
            <AnimatedText text="Journey" delay={0.15} />
          </span>
        </h2>

        <div className="relative">
          {/* Vertical timeline line */}
          <motion.div
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={VP_LINE}
            transition={{ duration: 1.2, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="absolute left-5 top-0 bottom-0 w-px hidden sm:block origin-top"
            style={{ background: "linear-gradient(to bottom, var(--accent), rgba(44,255,5,0.08))" }}
          />

          <div className="flex flex-col gap-10">
            {jobs.map((job, i) => (
              <motion.div
                key={job.title}
                initial={{ opacity: 0, x: -36 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={VP}
                transition={{ duration: 0.65, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                className="relative sm:pl-16"
              >
                {/* Timeline dot */}
                <motion.div
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  viewport={VP}
                  transition={{ duration: 0.35, delay: i * 0.1 + 0.2 }}
                  className="absolute left-0 top-6 w-10 h-10 rounded-full hidden sm:flex items-center justify-center"
                  style={{
                    background: job.current ? "var(--accent-dim)" : "#0a0a0a",
                    border: `2px solid ${job.current ? "var(--accent)" : "var(--border-bright)"}`,
                    color: job.current ? "var(--accent)" : "var(--text-dim)",
                    zIndex: 1,
                  }}
                >
                  <FaBriefcase size={14} />
                </motion.div>

                {/* Card */}
                <motion.div
                  whileHover={{ y: -3 }}
                  className="card p-6 sm:p-7 relative overflow-hidden"
                  style={{ borderLeft: `2px solid ${job.current ? "var(--accent)" : "var(--border-bright)"}` }}
                >
                  {job.current && (
                    <div className="absolute top-0 left-0 w-full h-full pointer-events-none rounded-xl"
                      style={{ background: "radial-gradient(ellipse at top left, rgba(44,255,5,0.04) 0%, transparent 60%)" }} />
                  )}

                  <div className="flex flex-wrap items-start justify-between gap-3 mb-5">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base sm:text-lg font-black" style={{ color: "var(--text)" }}>
                          {job.title}
                        </h3>
                        {job.current && (
                          <motion.span
                            animate={{ opacity: [1, 0.5, 1] }}
                            transition={{ duration: 2, repeat: Infinity }}
                            className="text-xs px-2.5 py-0.5 rounded-full font-bold"
                            style={{
                              background: "var(--accent-dim)",
                              border: "1px solid rgba(44,255,5,0.3)",
                              color: "var(--accent)",
                            }}
                          >
                            Current
                          </motion.span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 mt-2 text-sm font-semibold" style={{ color: "var(--accent)" }}>
                        <HiOfficeBuilding size={13} />
                        {job.company}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1 text-xs" style={{ color: "var(--text-dim)" }}>
                        <FaMapMarkerAlt size={10} />
                        {job.location}
                      </div>
                    </div>
                    <div
                      className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full flex-shrink-0"
                      style={{ background: "var(--accent-dim)", border: "1px solid rgba(44,255,5,0.2)", color: "var(--accent)" }}
                    >
                      <FaCalendarAlt size={10} />
                      {job.period}
                    </div>
                  </div>

                  <div className="h-px mb-4" style={{ background: "var(--border)" }} />

                  <ul className="flex flex-col gap-2.5">
                    {job.bullets.map((b, bi) => (
                      <motion.li
                        key={bi}
                        initial={{ opacity: 0, x: -10 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={VP}
                        transition={{ duration: 0.35, delay: bi * 0.03 + 0.15 }}
                        className="text-xs sm:text-sm flex items-start gap-2.5 leading-relaxed"
                        style={{ color: "var(--text-muted)" }}
                      >
                        <span className="mt-1.5 w-1 h-1 rounded-full flex-shrink-0" style={{ background: "var(--accent)" }} />
                        {b}
                      </motion.li>
                    ))}
                  </ul>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
