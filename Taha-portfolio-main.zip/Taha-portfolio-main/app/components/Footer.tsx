"use client";

import { motion } from "framer-motion";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Skills", href: "#skills" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];

export default function Footer() {
  return (
    <footer className="py-8 px-6" style={{ borderTop: "1px solid var(--border)" }}>
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <span className="text-sm font-black" style={{ color: "var(--text)" }}>
          T<span style={{ color: "var(--accent)" }}>.</span>Asghar
        </span>
        <p className="text-xs" style={{ color: "var(--text-dim)" }}>
          © {new Date().getFullYear()} Taha Asghar — Warehouse & Logistics Professional
        </p>
        <div className="flex gap-5">
          {navLinks.map(({ label, href }) => (
            <motion.a
              key={href}
              href={href}
              whileHover={{ color: "var(--accent)" }}
              className="text-xs transition-colors"
              style={{ color: "var(--text-dim)" }}
            >
              {label}
            </motion.a>
          ))}
        </div>
      </div>
    </footer>
  );
}
