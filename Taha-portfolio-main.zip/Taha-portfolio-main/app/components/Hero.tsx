"use client";

import { useEffect, useState, useRef } from "react";
import { motion } from "framer-motion";
import { FaArrowDown } from "react-icons/fa";
import { HiOutlineLocationMarker } from "react-icons/hi";

const TITLES = [
  "Warehouse & Logistics Professional",
  "Oracle ERP & Power BI Expert",
  "Supply Chain Coordinator",
  "Inventory Control Specialist",
];

function TypewriterText({ texts }: { texts: string[] }) {
  const [idx, setIdx] = useState(0);
  const [displayed, setDisplayed] = useState("");
  const [deleting, setDeleting] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const current = texts[idx];
    if (!deleting && displayed.length < current.length) {
      timeoutRef.current = setTimeout(() => setDisplayed(current.slice(0, displayed.length + 1)), 55);
    } else if (!deleting && displayed.length === current.length) {
      timeoutRef.current = setTimeout(() => setDeleting(true), 2400);
    } else if (deleting && displayed.length > 0) {
      timeoutRef.current = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 30);
    } else if (deleting && displayed.length === 0) {
      setDeleting(false);
      setIdx((i) => (i + 1) % texts.length);
    }
    return () => { if (timeoutRef.current) clearTimeout(timeoutRef.current); };
  }, [displayed, deleting, idx, texts]);

  return (
    <span className="inline-flex items-center gap-1">
      <span style={{ color: "var(--accent)" }}>{displayed}</span>
      <span className="inline-block w-0.5 h-5 animate-blink" style={{ background: "var(--accent)", boxShadow: "0 0 8px var(--accent)" }} />
    </span>
  );
}

const nameChars = "Taha Asghar".split("");

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden grid-bg">
      {/* Radial glow */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: "radial-gradient(ellipse 70% 50% at 50% 60%, rgba(44,255,5,0.05) 0%, transparent 70%)",
      }} />

      {/* Corner accents */}
      <div className="absolute top-20 left-8 w-16 h-16 pointer-events-none opacity-20"
        style={{ borderTop: "2px solid var(--accent)", borderLeft: "2px solid var(--accent)" }} />
      <div className="absolute bottom-20 right-8 w-16 h-16 pointer-events-none opacity-20"
        style={{ borderBottom: "2px solid var(--accent)", borderRight: "2px solid var(--accent)" }} />

      <div className="relative z-10 text-center max-w-3xl mx-auto">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.85 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="mb-8 inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase"
          style={{ background: "var(--accent-dim)", border: "1px solid rgba(44,255,5,0.3)", color: "var(--accent)" }}
        >
          <span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "var(--accent)", boxShadow: "0 0 6px var(--accent)" }} />
          <HiOutlineLocationMarker size={12} />
          Jeddah, Saudi Arabia
        </motion.div>

        {/* Animated name — char by char */}
        <h1 className="text-5xl sm:text-6xl md:text-8xl font-black tracking-tight mb-5 leading-none">
          {nameChars.map((char, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 40, filter: "blur(8px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.5, delay: 0.3 + i * 0.04, ease: [0.22, 1, 0.36, 1] }}
              className="inline-block"
              style={{
                color: char === " " ? "transparent" : "var(--text)",
                whiteSpace: char === " " ? "pre" : "normal",
              }}
            >
              {char === " " ? " " : char}
            </motion.span>
          ))}
        </h1>

        {/* Accent underline */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 0.8, delay: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="mx-auto mb-6 h-0.5 w-32 origin-left"
          style={{ background: "var(--accent)", boxShadow: "0 0 12px var(--accent)" }}
        />

        {/* Typewriter */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="text-lg sm:text-xl md:text-2xl font-medium mb-8 h-8 flex items-center justify-center"
          style={{ color: "var(--text-muted)" }}
        >
          <TypewriterText texts={TITLES} />
        </motion.div>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 1.1, ease: [0.22, 1, 0.36, 1] }}
          className="text-sm sm:text-base leading-relaxed mb-10 max-w-lg mx-auto"
          style={{ color: "var(--text-muted)" }}
        >
          2+ year at Tamer Logistics driving inbound operations, inventory accuracy,
          and data-informed decisions with Oracle ERP & Power BI.
        </motion.p>

        {/* CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.25 }}
          className="flex flex-wrap gap-4 justify-center"
        >
          <motion.a
            href="#experience"
            whileHover={{ scale: 1.05, boxShadow: "0 0 30px rgba(44,255,5,0.4)" }}
            whileTap={{ scale: 0.96 }}
            className="px-8 py-3 rounded-xl text-sm font-black tracking-wide text-black transition-all duration-200"
            style={{ background: "var(--accent)" }}
          >
            View My Work
          </motion.a>
          <motion.a
            href="#contact"
            whileHover={{ scale: 1.05, borderColor: "var(--accent)", color: "var(--accent)" }}
            whileTap={{ scale: 0.96 }}
            className="px-8 py-3 rounded-xl text-sm font-bold transition-all duration-200"
            style={{ border: "1px solid var(--border-bright)", color: "var(--text-muted)" }}
          >
            Contact Me
          </motion.a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 0.6 }}
          className="mt-16 flex flex-wrap justify-center gap-10 sm:gap-16"
        >
          {[
            { value: "2+", label: "Years Experience" },
            { value: "Oracle", label: "ERP System" },
            { value: "Power BI", label: "Data Reports" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.5 + i * 0.1 }}
              className="text-center"
            >
              <div className="text-xl sm:text-2xl font-black" style={{ color: "var(--accent)" }}>{s.value}</div>
              <div className="text-xs mt-1 tracking-wide" style={{ color: "var(--text-dim)" }}>{s.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-xs tracking-widest uppercase" style={{ color: "var(--text-dim)" }}>Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: "easeInOut" }}
          style={{ color: "var(--accent)" }}
        >
          <FaArrowDown size={14} />
        </motion.div>
      </motion.div>
    </section>
  );
}
