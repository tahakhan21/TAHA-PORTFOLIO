"use client";

import { motion } from "framer-motion";
import { FaGraduationCap, FaBox, FaChartBar, FaCog, FaTrophy, FaMedal } from "react-icons/fa";
import AnimatedText from "./AnimatedText";

const VP = { once: false, margin: "-60px" } as const;

const education = [
  {
    degree: "Bachelor of Science – Computer Science",
    institution: "COMSATS Institute of Information Technology",
    location: "Wah Cantt, Pakistan",
    Icon: FaGraduationCap,
  },
];

const certs = [
  { name: "Logistics Excellence",                         issuer: "Rutgers University of New Jersey", Icon: FaBox },
  { name: "Extract, Transform, and Load Data in Power BI", issuer: "Microsoft",                       Icon: FaChartBar },
  { name: "SAP Professional Fundamentals",                issuer: "Coursera",                         Icon: FaCog },
];

const awards = [
  {
    title: "Employee of the Year",
    org: "Tamer Logistics",
    desc: "Recognized for outstanding performance, operational excellence, and consistent results.",
    Icon: FaTrophy,
  },
  {
    title: "2nd Position — National Quiz Competition",
    org: "CUST (Pakistan-wide)",
    desc: "Secured 2nd place in a competitive nationwide academic quiz competition.",
    Icon: FaMedal,
  },
];

const bars = [
  { label: "Oracle ERP / SAP",  val: 85 },
  { label: "Power BI & ETL",    val: 80 },
  { label: "Microsoft Excel",   val: 90 },
  { label: "Inventory Control", val: 95 },
];

export default function EducationCerts() {
  return (
    <section id="education" className="py-28 px-6 relative" style={{ background: "#040404" }}>
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -24 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={VP}
          transition={{ duration: 0.5 }}
        >
          <span className="section-label">Credentials</span>
        </motion.div>

        <h2 className="text-4xl sm:text-5xl font-black mb-14 leading-tight">
          <AnimatedText text="Education &" delay={0.05} />
          <br />
          <span style={{ color: "var(--accent)" }}>
            <AnimatedText text="Certifications" delay={0.25} />
          </span>
        </h2>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* LEFT */}
          <div className="flex flex-col gap-8">
            {/* Education */}
            <div>
              <motion.h3
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ delay: 0.1 }}
                className="text-xs font-black uppercase tracking-widest mb-4"
                style={{ color: "var(--text-dim)" }}
              >
                Education
              </motion.h3>
              {education.map(({ degree, institution, location, Icon }, i) => (
                <motion.div
                  key={degree}
                  initial={{ opacity: 0, x: -24 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={VP}
                  transition={{ duration: 0.6, delay: 0.12 + i * 0.1 }}
                  whileHover={{ y: -3, borderColor: "rgba(44,255,5,0.35)" }}
                  className="card p-5 flex gap-4"
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "var(--accent-dim)", color: "var(--accent)", border: "1px solid rgba(44,255,5,0.2)" }}
                  >
                    <Icon size={20} />
                  </div>
                  <div>
                    <div className="font-black text-sm" style={{ color: "var(--text)" }}>{degree}</div>
                    <div className="text-xs font-semibold mt-1" style={{ color: "var(--accent)" }}>{institution}</div>
                    <div className="text-xs mt-1" style={{ color: "var(--text-dim)" }}>{location}</div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Certifications */}
            <div>
              <motion.h3
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ delay: 0.15 }}
                className="text-xs font-black uppercase tracking-widest mb-4"
                style={{ color: "var(--text-dim)" }}
              >
                Certifications
              </motion.h3>
              <div className="flex flex-col gap-3">
                {certs.map(({ name, issuer, Icon }, i) => (
                  <motion.div
                    key={name}
                    initial={{ opacity: 0, x: -18 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={VP}
                    transition={{ duration: 0.5, delay: 0.2 + i * 0.08 }}
                    whileHover={{ y: -2, borderColor: "rgba(44,255,5,0.35)" }}
                    className="card p-4 flex items-center gap-3"
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: "var(--accent-dim)", color: "var(--accent)" }}
                    >
                      <Icon size={14} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate" style={{ color: "var(--text)" }}>{name}</div>
                      <div className="text-xs mt-0.5" style={{ color: "var(--text-dim)" }}>{issuer}</div>
                    </div>
                    <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: "var(--accent)" }} />
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT */}
          <div className="flex flex-col gap-6">
            <motion.h3
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={VP}
              transition={{ delay: 0.12 }}
              className="text-xs font-black uppercase tracking-widest"
              style={{ color: "var(--text-dim)" }}
            >
              Awards & Achievements
            </motion.h3>

            {awards.map(({ title, org, desc, Icon }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={VP}
                transition={{ duration: 0.6, delay: 0.18 + i * 0.12 }}
                whileHover={{ y: -3, borderColor: "rgba(44,255,5,0.35)" }}
                className="card p-5 relative overflow-hidden"
              >
                <div
                  className="absolute top-0 right-0 w-24 h-24 pointer-events-none rounded-xl"
                  style={{ background: "radial-gradient(circle, rgba(44,255,5,0.05) 0%, transparent 70%)", transform: "translate(30%,-30%)" }}
                />
                <div className="flex items-start gap-4">
                  <motion.div
                    animate={{ rotate: [-4, 4, -4] }}
                    transition={{ duration: 2.8, repeat: Infinity, ease: "easeInOut" }}
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "var(--accent-dim)", color: "var(--accent)", border: "1px solid rgba(44,255,5,0.2)" }}
                  >
                    <Icon size={18} />
                  </motion.div>
                  <div>
                    <div className="font-black text-sm" style={{ color: "var(--text)" }}>{title}</div>
                    <div className="text-xs font-semibold mt-1" style={{ color: "var(--accent)" }}>{org}</div>
                    <p className="text-xs mt-1.5 leading-relaxed" style={{ color: "var(--text-dim)" }}>{desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Skill bars */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={VP}
              transition={{ duration: 0.6, delay: 0.42 }}
              className="card p-5"
            >
              <h4 className="text-xs font-black uppercase tracking-widest mb-5" style={{ color: "var(--text-dim)" }}>
                Technical Proficiency
              </h4>
              <div className="flex flex-col gap-4">
                {bars.map(({ label, val }, bi) => (
                  <div key={label}>
                    <div className="flex justify-between text-xs mb-1.5">
                      <span style={{ color: "var(--text-muted)" }}>{label}</span>
                      <motion.span
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={VP}
                        transition={{ delay: 0.55 + bi * 0.08 }}
                        style={{ color: "var(--accent)" }}
                      >
                        {val}%
                      </motion.span>
                    </div>
                    <div className="h-1 rounded-full overflow-hidden" style={{ background: "var(--border)" }}>
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${val}%` }}
                        viewport={VP}
                        transition={{ duration: 1.1, delay: 0.5 + bi * 0.09, ease: [0.22, 1, 0.36, 1] }}
                        className="h-full rounded-full"
                        style={{ background: "var(--accent)", boxShadow: "0 0 8px rgba(44,255,5,0.4)" }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
